echo "instructor name :"
read a
grep $a timetable.csv |cut -d',' -f3 |sort| uniq | wc -l
