room="$1"
echo "Empty slots for room: $room"

d=$(grep $1 timetable.csv|cut -d',' -f1|sort|uniq)
s=$(grep $1 timetable.csv|cut -d',' -f2|sort|uniq)

for day in $d; do
  for slot in $s; do
    EXISTS=$(awk -F',' -v d="$day" -v t="$slot" -v r="$room" '$1==d && $2==t && $5==r' timetable.csv)
    
    if [ -z "$EXISTS" ]; then
      echo "$day,$slot is FREE"
    fi
  done
done
