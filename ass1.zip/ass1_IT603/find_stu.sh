id=$1

b=$(grep $id global_students.csv |cut -d',' -f2)

c=$(grep $b timetable_all_batches.csv|cut -d',' -f5|uniq)
echo $c

