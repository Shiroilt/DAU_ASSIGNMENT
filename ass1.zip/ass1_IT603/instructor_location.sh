i="$1"

c=$(grep $1 timetable.csv|cut -d',' -f5|sort|uniq)
slots=('08:00-08:50' '09:00-09:50' '10:00-10:50' '11:00-11:50' '12:00-12:50')
d=$(grep $1 timetable.csv|cut -d',' -f1|sort|uniq)
for d in $d; do
  for slot in "${slots[@]}"; do
    EXISTS=$(awk -F',' -v d="$d" -v t="$slot" -v i="$1" '$1==d && $2==t && $4==i' timetable.csv)
    echo $d
    if [ -n "$EXISTS" ]; then
      echo "in class $slot"
    else
      echo "office   $slot"
    fi
    done
done
