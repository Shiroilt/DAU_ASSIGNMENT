
echo "Course name :"
read a
grep $a timetable.csv  
