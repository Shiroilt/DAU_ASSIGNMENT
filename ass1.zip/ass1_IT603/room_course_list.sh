echo "Room num :"
read a
awk -F',' -v r="$a" '$5 == r { print $3 }' timetable.csv|uniq
