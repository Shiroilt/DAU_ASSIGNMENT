a=$(date +%A)
grep "$a" timetable.csv
