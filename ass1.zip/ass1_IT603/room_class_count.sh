#echo "Room num :"
#read a
#`grep Friday timetable.csv|awk -F',' -v r="$a" '$5 == r { print $3 }'|uniq|wc -l

echo "Room, Day, Count"
awk -F',' '{print $5 "," $1}' timetable.csv | sort | uniq -c | while read count line; do
    echo "$line,$count"
done
